<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LiveData extends Model
{
    //
    protected $table = 'live_data';
}
