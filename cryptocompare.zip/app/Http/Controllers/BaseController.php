<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

define('ZERO', 0);
define('BASE_URL', 'http://18.191.39.172/cryptocompare');
define('IMAGE_BASE_URL', 'http://18.191.39.172/cryptocompare/public/');

//http://106.51.49.48/comp/ico http://18.191.39.172/cryptocompare/
class BaseController extends Controller
{
    //
}
